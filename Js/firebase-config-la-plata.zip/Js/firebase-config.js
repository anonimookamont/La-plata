// Configuração pública do Firebase para o navegador.
// Substitua os valores abaixo pelos dados de Configuração do SDK do seu projeto Firebase.
// NÃO coloque aqui FIREBASE_PRIVATE_KEY, conta de serviço ou tokens PushinPay.
import { initializeApp, getApps, getApp } from 'https://www.gstatic.com/firebasejs/10.8.0/firebase-app.js';
import { getAuth } from 'https://www.gstatic.com/firebasejs/10.8.0/firebase-auth.js';
import { getFirestore } from 'https://www.gstatic.com/firebasejs/10.8.0/firebase-firestore.js';

const firebaseConfig = {
  apiKey: 'SUBSTITUA_PELA_API_KEY_DO_FIREBASE',
  authDomain: 'SUBSTITUA_PELO_AUTH_DOMAIN',
  projectId: 'SUBSTITUA_PELO_PROJECT_ID',
  storageBucket: 'SUBSTITUA_PELO_STORAGE_BUCKET',
  messagingSenderId: 'SUBSTITUA_PELO_MESSAGING_SENDER_ID',
  appId: 'SUBSTITUA_PELO_APP_ID'
};

const app = getApps().length ? getApp() : initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);
